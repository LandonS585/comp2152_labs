# Lab04
# Student Name: Landon Swales
# Date: Feb 8th, 2026


# Question 1: Robot Return to Origin (Loops + State Tracking)

def robot_returns_to_origin(moves):
    # Initialize starting position
    x = 0
    y = 0

    # Loop through each move
    for move in moves:
        if move == 'U':
            y += 1
        elif move == 'D':
            y -= 1
        elif move == 'L':
            x -= 1
        elif move == 'R':
            x += 1

    return x == 0 and y == 0


# Test cases for Question 1
test_moves = ["UD", "LL", "UDLR", "LDRRLRUULR"]

for moves in test_moves:
    result = robot_returns_to_origin(moves)
    print("Moves '" + moves + "': Returns to origin? " + str(result))

print()


# Question 2: Two Sum (Nested Loops vs Dictionary)

# Part A: Brute Force with Nested Loops
def two_sum_brute_force(numbers, target):
    for i in range(len(numbers)):
        for j in range(i + 1, len(numbers)):
            if numbers[i] + numbers[j] == target:
                return (i, j)
    return None


# Part B: Optimized with Dictionary
def two_sum_optimized(numbers, target):
    seen = {}  # {number: index}

    for i in range(len(numbers)):
        needed = target - numbers[i]

        if needed in seen:
            return (seen[needed], i)

        seen[numbers[i]] = i

    return None


# Test cases for Question 2
test_cases = [
    ([2, 7, 11, 15], 9),
    ([3, 2, 4], 6),
    ([3, 3], 6),
    ([1, 5, 3, 8, 2], 10)
]

print("=== Part A: Brute Force (Nested Loops) ===")
for numbers, target in test_cases:
    result = two_sum_brute_force(numbers, target)
    print("Numbers: " + str(numbers) + ", Target: " + str(target))
    print("Result: " + str(result))
    print()

print("=== Part B: Optimized (Dictionary) ===")
for numbers, target in test_cases:
    result = two_sum_optimized(numbers, target)
    print("Numbers: " + str(numbers) + ", Target: " + str(target))
    print("Result: " + str(result))
    print()


# Question 3: Shuffle the Array (List Slicing + Loops)

def shuffle_array(nums, n):
    # Step 1: Split into two halves
    first_half = nums[:n]
    second_half = nums[n:]

    # Step 2: Interleave elements
    result = []
    for i in range(n):
        result.append(first_half[i])
        result.append(second_half[i])

    return result


# Test cases for Question 3
test_cases = [
    ([2, 5, 1, 3, 4, 7], 3),
    ([1, 2, 3, 4, 4, 3, 2, 1], 4),
    ([1, 1, 2, 2], 2)
]

for nums, n in test_cases:
    print("Original: " + str(nums))
    print("n = " + str(n))
    print("First half (nums[:" + str(n) + "]): " + str(nums[:n]))
    print("Second half (nums[" + str(n) + ":]): " + str(nums[n:]))
    print("Shuffled: " + str(shuffle_array(nums, n)))
    print()


# Question 4: First Unique Character (Dictionary + Two-Pass Loop)

def count_characters(s):
    counts = {}
    for char in s:
        if char in counts:
            counts[char] += 1
        else:
            counts[char] = 1
    return counts


def first_unique_character(s):
    char_counts = count_characters(s)

    for i in range(len(s)):
        if char_counts[s[i]] == 1:
            return i

    return -1


# Test cases for Question 4
test_strings = ["leetcode", "loveleetcode", "aabb", "python", "aabbcc"]

for s in test_strings:
    index = first_unique_character(s)

    if index != -1:
        print("First unique character in '" + s + "': index " + str(index) +
              " (character: '" + s[index] + "')")
    else:
        print("First unique character in '" + s + "': index -1 (no unique character)")

    print("  Character counts: " + str(count_characters(s)))
    print()
